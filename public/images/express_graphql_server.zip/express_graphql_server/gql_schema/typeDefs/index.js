import root from "./root.js";

import customers from "./customers.js";
import image from "./image.js";
import product_category from "./product_category.js";
import product_subcategory from "./product_subcategory.js";
import products from "./products.js";
import purchase from "./purchase.js";
import sales from "./sales.js";
import store from "./store.js";
import supplier from "./supplier.js";

export default [
  root,
  customers,
  image,
  product_category,
  product_subcategory,
  products,
  purchase,
  sales,
  store,
  supplier,
];
